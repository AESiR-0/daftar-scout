export default function StudioPage() {
    return <div>Studio</div>
}
